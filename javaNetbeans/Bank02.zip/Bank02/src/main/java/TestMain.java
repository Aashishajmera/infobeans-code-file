public class TestMain {
    public static void main(String[] args) {
        // create a object of operation class

        Operation objO = new Operation();
        objO.main();
    }
}
