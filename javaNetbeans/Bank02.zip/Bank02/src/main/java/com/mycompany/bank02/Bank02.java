/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bank02;

/**
 *
 * @author hp
 */
public class Bank02 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
