export default [
    {
        rollno : 1001,
        name: 'Bhola',
        branch: 'IT',
        mob: 8103202647
    },
    {
        rollno : 1002,
        name: 'Vinay',
        branch: 'CS',
        mob: 8103256647
    },
    {
        rollno : 1003,
        name: 'Anjali',
        branch: 'CS',
        mob: 8103202747
    },
    {
        rollno : 1004,
        name: 'Dhara',
        branch: 'MECH',
        mob: 8148826479
    },
    {
        rollno : 1005,
        name: 'Rahul',
        branch: 'IT',
        mob: 7000718505
    },
    
]