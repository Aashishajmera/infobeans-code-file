import express from 'express';
import { orderDeliver } from '../controller/deliveryData.controller.js';


const router = express.Router();
router.use("/orderDeliver",orderDeliver);

export default router