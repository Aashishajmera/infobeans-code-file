import express from 'express';
import { addCategory,addCategoryInBulk ,viewCategory} from '../controller/category.controller.js';
 
const router = express.Router();
router.post("/addCategory",addCategory)
router.post("/addCategoryInBulk",addCategoryInBulk)
router.get("/viewcategory",viewCategory)
// router.get("productbyCategory",productByCategory);
export default router;