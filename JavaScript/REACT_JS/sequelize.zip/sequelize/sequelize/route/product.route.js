import express from 'express';
import { addProduct, viewAllProducts,viewAllByCategory,removeProduct,addProductInBulk,getProductById } from '../controller/product.controller.js';
 
const router = express.Router();
router.post("/addProduct",addProduct)
router.post("/addProductInBulk",addProductInBulk)
router.get("/viewAll/:categoryName",viewAllByCategory)
router.get("/viewAllProducts",viewAllProducts)
router.post("/removeProduct",removeProduct)
router.get("/getProductById/:id",getProductById)


export default router;